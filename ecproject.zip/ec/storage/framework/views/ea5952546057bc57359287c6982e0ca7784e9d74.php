<?php $__env->startSection('content'); ?>
<div class="container">
        <h3 style="text-align:center;color:purple;">Your Item in Cart list</h3>
    <?php if(isset($product)): ?>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="container-fluid">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="search-item mt-2 cart-list-devider">
                                    <a href="detail/<?php echo e($item->id); ?>">
                                        <img src="<?php echo e(asset('assets/'.$item->file)); ?>">
                                    </a>
                                    
                                </div>
                            </div>
                            <div class="col-sm-4">  
                                <h5> Product Name : <?php echo e($item->name); ?></h5>
                                <h5>Description : <?php echo e($item->description); ?></h5>
                                <h5> Product file :<?php echo e($item->file); ?></h5>
                                <a class="btn btn-success" href="ordernow">Order now</a> <br><br>
                                <a href="/removecart/<?php echo e($item->cart_id); ?>" class="btn btn-warning">Remove to cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(count($product) ==  0): ?>
        <h3>No Item in Cart list</h5>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>                  
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ec/resources/views/cartlist.blade.php ENDPATH**/ ?>