<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php echo e($data->name); ?>

    <?php echo e($data->description); ?>

    <iframe src="/assets/<?php echo e($data->file); ?>" height="400" width="400"></iframe>
</body>
</html><?php /**PATH /var/www/html/ec/resources/views/viewproduct.blade.php ENDPATH**/ ?>