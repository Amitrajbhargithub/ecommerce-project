<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>upload file</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('fail')): ?>
        <h1><?php echo e(session('fail')); ?></h1>
    <?php endif; ?>
    <form action="<?php echo e(url('uploadproduct')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Product name" />
        <input type="text" name="description" placeholder="product description"/>
        <input type="file" name="file">
        <input type="submit" value="save">
    </form>
</body>
</html><?php /**PATH /var/www/html/ec/resources/views/upload.blade.php ENDPATH**/ ?>