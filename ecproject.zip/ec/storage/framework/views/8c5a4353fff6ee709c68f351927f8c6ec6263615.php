<h1>welcome page</h1>
<?php /**PATH /var/www/html/ec/resources/views/welcome.blade.php ENDPATH**/ ?>