<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 style="text-align:center;color:purple;">Myorders product</h3>
     <div class="row">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="search-item mt-2 cart-list-devider">
                <a href="detail/<?php echo e($item->id); ?>"></a> 
                    <img src="<?php echo e(asset('assets/'.$item->file)); ?>">
                    <h5>Product Name :<?php echo e($item->name); ?></h5>
                    <h5>Delivery status : <?php echo e($item->status); ?></h5>
                    <h5>Address : <?php echo e($item->address); ?></h5>
                    <h5>Payment status <?php echo e($item->payment_status); ?></h5>
                    <h5>Payment method <?php echo e($item->payment_method); ?></h5>
                    <h5><?php echo e($item->name); ?></h5>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div> <br>
   
</div>
<?php $__env->stopSection(); ?>           
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ec/resources/views/myorders.blade.php ENDPATH**/ ?>