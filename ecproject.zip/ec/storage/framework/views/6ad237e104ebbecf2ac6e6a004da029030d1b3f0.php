<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>show all data</h1>
    <table border="1">
            <tr>
                <th>Name</th>
                <th>description</th>
                <th>View</th>
                <th>Download</th>
            </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><a href="<?php echo e(url('view',$item->id)); ?>">View</a></td>
                <td><a href="<?php echo e(url('/download',$item->file)); ?>">Download</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH /var/www/html/ec/resources/views/showproduct.blade.php ENDPATH**/ ?>