<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 style="text-align:center;color:purple;">Result for product</h3>
     <div class="row">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="container-fluid">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="search-item mt-2 cart-list-devider">
                                    <a href="detail/<?php echo e($item->id); ?>">
                                        <img src="<?php echo e(asset('assets/'.$item->file)); ?>">
                                    </a>
                                    
                                </div>
                            </div>
                            <div class="col-sm-4">  
                                <h5> Product Name : <?php echo e($item->name); ?></h5>
                                <h5>Description : <?php echo e($item->description); ?></h5>
                                <h5> Product file :<?php echo e($item->file); ?></h5>
                                <form action="/add_to_card">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($item['id']); ?>">
                                    <button class="btn btn-primary">Add to Cart</button><br><br>
                                    <a class="btn btn-success" href="ordernow">Order now</a> <br><br>
                                </form><br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
</div>
<?php $__env->stopSection(); ?>           

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ec/resources/views/search.blade.php ENDPATH**/ ?>